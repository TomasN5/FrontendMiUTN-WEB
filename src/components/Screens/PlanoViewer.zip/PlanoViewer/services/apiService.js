import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

// 🔥 CACHÉ MEJORADO - Evita llamadas repetidas
const cache = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutos

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 segundos timeout
});

// 🔥 FUNCIÓN PARA MANEJAR CACHÉ
const getFromCache = (key) => {
  const cached = cache.get(key);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.data;
  }
  return null;
};

const setToCache = (key, data) => {
  cache.set(key, {
    data,
    timestamp: Date.now()
  });
};

const clearCache = (key) => {
  if (key) {
    cache.delete(key);
  } else {
    cache.clear();
  }
};

export const planoService = {
  obtenerDatosPlano: async (planoId) => {
    const cacheKey = `plano_${planoId}`;
    
    // 🔥 VERIFICAR CACHÉ PRIMERO
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      console.log('📦 Usando datos en caché para:', planoId);
      return cachedData;
    }

    try {
      const response = await api.get(`/planos/${planoId}/datos`);
      const data = response.data;
      
      // 🔥 GUARDAR EN CACHÉ
      setToCache(cacheKey, data);
      console.log('✅ Datos cargados y guardados en caché:', planoId);
      
      return data;
    } catch (error) {
      console.warn('Error obteniendo datos del plano, usando datos vacíos');
      const datosVacios = {
        planoId,
        nodos: [],
        pasillos: []
      };
      
      // 🔥 GUARDAR DATOS VACÍOS EN CACHÉ PARA EVITAR MÁS LLAMADAS
      setToCache(cacheKey, datosVacios);
      return datosVacios;
    }
  },

  guardarDatosPlano: async (planoId, datosPlano) => {
    try {
      const response = await api.post(`/planos/${planoId}/datos`, datosPlano);
      
      // 🔥 LIMPIAR CACHÉ DESPUÉS DE GUARDAR
      clearCache(`plano_${planoId}`);
      console.log('🧹 Cache limpiado después de guardar:', planoId);
      
      return response.data;
    } catch (error) {
      console.error('Error guardando datos del plano:', error);
      throw error;
    }
  },

  // 🔥 NUEVO: Limpiar caché manualmente
  limpiarCache: (planoId) => {
    if (planoId) {
      clearCache(`plano_${planoId}`);
    } else {
      clearCache();
    }
    console.log('🧹 Cache limpiado');
  }
};

export const nodoService = {
  crearNodo: async (nodoDTO) => {
    const response = await api.post('/nodos', nodoDTO);
    
    // 🔥 LIMPIAR CACHÉ DEL PLANO DESPUÉS DE CREAR
    if (nodoDTO.planoId) {
      planoService.limpiarCache(nodoDTO.planoId);
    }
    
    return response.data;
  },

  actualizarNodo: async (id, nodoDTO) => {
    const response = await api.put(`/nodos/${id}`, nodoDTO);
    
    // 🔥 LIMPIAR CACHÉ DEL PLANO DESPUÉS DE ACTUALIZAR
    if (nodoDTO.planoId) {
      planoService.limpiarCache(nodoDTO.planoId);
    }
    
    return response.data;
  },

 eliminarNodo: async (id, planoId = null) => {
  try {
    // 🔥 CORREGIDO: Usar el endpoint correcto
    const response = await api.delete(`/nodos/${id}`);
    console.log('✅ Nodo eliminado en backend:', id, response.status);
    
    // 🔥 LIMPIAR CACHÉ DEL PLANO SI SE PROVEE
    if (planoId) {
      planoService.limpiarCache(planoId);
    }
    
    return response.data;
  } catch (error) {
    console.error('❌ Error eliminando nodo en backend:', error);
    
    // 🔥 MEJOR MANEJO DE ERRORES
    if (error.response?.status === 404) {
      console.warn(`⚠️ Nodo ${id} no encontrado en backend, pero se eliminará localmente`);
      // Continuar con la eliminación local aunque falle en backend
      return { success: true, message: 'Eliminado localmente' };
    }
    throw error;
  }
},

  obtenerNodosPorPlano: async (planoId) => {
    const cacheKey = `nodos_${planoId}`;
    
    // 🔥 USAR CACHÉ
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      return cachedData;
    }

    const response = await api.get(`/nodos/plano/${planoId}`);
    setToCache(cacheKey, response.data);
    return response.data;
  },

  obtenerTodosNodos: async () => {
    const cacheKey = 'todos_nodos';
    
    // 🔥 USAR CACHÉ
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      return cachedData;
    }

    const response = await api.get('/nodos');
    setToCache(cacheKey, response.data);
    return response.data;
  },
};

export const pasilloService = {
  crearPasillo: async (pasilloDTO) => {
    const response = await api.post('/pasillos', pasilloDTO);
    
    // 🔥 LIMPIAR CACHÉ DEL PLANO DESPUÉS DE CREAR
    if (pasilloDTO.planoId) {
      planoService.limpiarCache(pasilloDTO.planoId);
    }
    
    return response.data;
  },

  eliminarPasillo: async (id, planoId = null) => {
    await api.delete(`/pasillos/${id}`);
    
    // 🔥 LIMPIAR CACHÉ DEL PLANO SI SE PROVEE
    if (planoId) {
      planoService.limpiarCache(planoId);
    }
  },

  obtenerPasillosPorPlano: async (planoId) => {
    const cacheKey = `pasillos_${planoId}`;
    
    // 🔥 USAR CACHÉ
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      return cachedData;
    }

    const response = await api.get(`/pasillos/plano/${planoId}`);
    setToCache(cacheKey, response.data);
    return response.data;
  },

  obtenerPasillosPorNodo: async (nodoId) => {
    const cacheKey = `pasillos_nodo_${nodoId}`;
    
    // 🔥 USAR CACHÉ
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      return cachedData;
    }

    const response = await api.get(`/pasillos/nodo/${nodoId}`);
    setToCache(cacheKey, response.data);
    return response.data;
  },
};

export const floorService = {
  obtenerTodosFloors: async () => {
    const cacheKey = 'todos_floors';
    
    // 🔥 USAR CACHÉ
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      return cachedData;
    }

    const response = await api.get('/floors');
    setToCache(cacheKey, response.data);
    return response.data;
  },
};

export const careerService = {
  obtenerTodasCareers: async () => {
    const cacheKey = 'todos_careers';
    
    // 🔥 USAR CACHÉ
    const cachedData = getFromCache(cacheKey);
    if (cachedData) {
      return cachedData;
    }

    try {
      const response = await api.get('/api/v1/MiUTN/career/');
      // Convertir el Map<Long, String> a array de objetos
      const careersMap = response.data;
      const careersArray = Object.entries(careersMap).map(([id, name]) => ({
        id: parseInt(id),
        name: name
      }));
      
      setToCache(cacheKey, careersArray);
      return careersArray;
    } catch (error) {
      console.warn('Error obteniendo careers, usando datos temporales');
      const careersTemporales = [
        { id: 1, name: 'Sistemas' },
        { id: 2, name: 'Química' },
        { id: 3, name: 'Mecánica' },
        { id: 4, name: 'Civil' },
        { id: 5, name: 'Industrial' },
        { id: 6, name: 'Eléctrica' }
      ];
      
      setToCache(cacheKey, careersTemporales);
      return careersTemporales;
    }
  },
};

// 🔥 EXPORTAR FUNCIONES DE CACHÉ PARA USO EXTERNO
export const cacheService = {
  limpiarTodo: () => clearCache(),
  limpiarPorKey: (key) => clearCache(key),
  obtenerEstadisticas: () => ({
    total: cache.size,
    keys: Array.from(cache.keys())
  })
};

export default api;